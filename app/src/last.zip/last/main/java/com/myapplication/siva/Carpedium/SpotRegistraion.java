package com.myapplication.siva.Carpedium;

import android.app.ProgressDialog;

import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.myapplication.siva.Carpedium.Databases.SpotDB;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


public class SpotRegistraion extends AppCompatActivity {

    SpotDB controller = new SpotDB(this);
    ProgressDialog prgDialog;
    String regiNo;
    String Email;
    String Phone;
    String Name;

    String m_Text;
    private TextInputLayout inputLayoutName, inputLayoutEmail, inputLayoutNumber,inputLayoutPhone;

    EditText username,EmailID,Phoneno,regno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spot);
        String regino = null;
        //getSupportActionBar().show();

        inputLayoutName = (TextInputLayout) findViewById(R.id.input_layout_name1);
        inputLayoutEmail = (TextInputLayout) findViewById(R.id.input_layout_name2);
        inputLayoutNumber = (TextInputLayout) findViewById(R.id.input_layout_name3);
        inputLayoutPhone  = (TextInputLayout) findViewById(R.id.input_layout_name4);
        username = (EditText)findViewById(R.id.name);
        EmailID = (EditText)findViewById(R.id.Email);
        Phoneno = (EditText)findViewById(R.id.phone);
        regno = (EditText)findViewById(R.id.regiNo1);

        username.addTextChangedListener(new MyTextWatcher(username));
        EmailID.addTextChangedListener(new MyTextWatcher(EmailID));
        Phoneno.addTextChangedListener(new MyTextWatcher(Phoneno));
        regno.addTextChangedListener(new MyTextWatcher(regno));



       /* ListView myList=(ListView)findViewById(android.R.id.list);

        ArrayList<HashMap<String, String>> userList =  controller.getAllGroups();

        if(userList.size()!=0){
            ListAdapter adapter = new SimpleAdapter( SpotRegistraion.this,userList, R.layout.view_user_entry, new String[] { "userId","userName"}, new int[] {R.id.userId, R.id.userName});
            myList.setAdapter(adapter);
            Toast.makeText(getApplicationContext(), controller.getSyncStatus(), Toast.LENGTH_LONG).show();
        }*/


        prgDialog = new ProgressDialog(this);
        prgDialog.setMessage("Synching SQLite Data with Remote MySQL DB. Please wait...");
        prgDialog.setCancelable(false);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public void onOK(View view)
    {
        HashMap<String, String> queryValues = new HashMap<String, String>();


        regiNo = regno.getText().toString();
        Email = EmailID.getText().toString();
        Phone = Phoneno.getText().toString();
        Name = username.getText().toString();

        queryValues.put("EmailId", Email);
        queryValues.put("Phone", Phone);
        queryValues.put("userName", Name);
        queryValues.put("Regino",regiNo);
        controller.insertUser(queryValues);
        syncSQLiteMySQLDB();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.refresh) {
            syncSQLiteMySQLDB();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }



    public void syncSQLiteMySQLDB(){
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();

        ArrayList<HashMap<String, String>> userList =  controller.getAllGroups();
        if(userList.size()!=0){
            if(controller.dbSyncCount() != 0){
                prgDialog.show();
                params.put("usersJSON", controller.composeJSONfromSQLite());
                System.out.println(controller.composeJSONfromSQLite());
                client.post("http://carpe16.esy.es/carpe16/sync/Spotregister.php",params ,new AsyncHttpResponseHandler() {
                    @Override
                    public void onSuccess(String response) {
                        System.out.println(response);
                        prgDialog.hide();
                        try {
                            JSONArray arr = new JSONArray(response);
                            System.out.println(arr.length());
                            for(int i=0; i<arr.length();i++){
                                JSONObject obj = (JSONObject)arr.get(i);
                                System.out.println(obj.get("id"));
                                System.out.println(obj.get("status"));
                                controller.updateSyncStatus(obj.get("id").toString(),obj.get("status").toString());
                            }
                            Toast.makeText(getApplicationContext(), "DB Sync completed!", Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            // TODO Auto-generated catch block
                            Toast.makeText(getApplicationContext(), "Error Occured [Server's JSON response might be invalid]!", Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(int statusCode, Throwable error,
                                          String content) {
                        // TODO Auto-generated method stub
                        prgDialog.hide();
                        if(statusCode == 404){
                            Toast.makeText(getApplicationContext(), "Requested resource not found", Toast.LENGTH_LONG).show();
                        }else if(statusCode == 500){
                            Toast.makeText(getApplicationContext(), "Something went wrong at server end", Toast.LENGTH_LONG).show();
                        }else{
                            Toast.makeText(getApplicationContext(), "Unexpected Error occcured! [Most common Error: Device might not be connected to Internet]", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }else{
                Toast.makeText(getApplicationContext(), "SQLite and Remote MySQL DBs are in Sync!", Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(getApplicationContext(), "No data in SQLite DB, please do enter User name to perform Sync action", Toast.LENGTH_LONG).show();
        }
    }



    private class MyTextWatcher implements TextWatcher {

        private View view;

        private MyTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {

        }
    }

}
